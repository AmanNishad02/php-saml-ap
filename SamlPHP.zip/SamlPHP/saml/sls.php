<?php
require_once 'settings.php';
require_once 'vendor/autoload.php';

use OneLogin\Saml2\Logout;

// $logout = new Logout($settings);
$logout->processLogoutRequest();