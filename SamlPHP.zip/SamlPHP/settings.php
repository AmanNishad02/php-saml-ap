<?php
$settings = array(
    // Path to the SAML metadata file
    'idp_metadata' => 'https://dev-60700936.okta.com/app/exkgrx1d0yoaIFHaF5d7/sso/saml/metadata',
    
    // URL where the SP metadata can be found
    'sp_metadata' => 'http://localhost/SamlPHP/metadata.xml',
    
    // SP entity ID
    'sp_entityId' => 'http://localhost/SamlPHP/saml//acs.php',
    
    // SP assertion consumer service URL
    'sp_assertionConsumerService' => array(
        'url' => 'http://localhost/SamlPHP/saml/acs.php',
    ),
    
    // SP single logout service URL
    // 'sp_singleLogoutService' => array(
    //     'url' => 'http://localhost/saml/sls.php',
    // ),
);