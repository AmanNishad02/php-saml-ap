<!DOCTYPE html>
<html>
<head>
    <title>Welcome to My Application</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
            text-align: center;
        }
        h1 {
            color: #333;
        }
        p {
            color: #666;
            line-height: 1.5;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Welcome to My Application</h1>
        <p>You have successfully authenticated using SAML with Okta.</p>
        <p>This is the protected area of our application, where you can access exclusive features and content.</p>
        <a href="https://dev-60700936.okta.com/login/signout" class="btn">Logout</a>
    </div>
</body>
</html>
