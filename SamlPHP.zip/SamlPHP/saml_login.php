<?php
require_once('vendor/autoload.php');

$settings = array(
    'sp' => array(
        'entityId' => 'http://www.okta.com/exkgrx1d0yoaIFHaF5d7', // Entity ID of your Service Provider (SP)
        'assertionConsumerService' => array(
            'url' => 'http://localhost/SamlPHP/protected_area.php', // ACS URL where the IdP will send the response
        ),
        // Other SP settings as needed
    ),
    'idp' => array(
        'entityId' => 'http://www.okta.com/exkgrx1d0yoaIFHaF5d7', // Entity ID of the Identity Provider (IdP)
        'singleSignOnService' => array(
            'url' => 'https://dev-60700936.okta.com/app/dev-60700936_samplephpapp_1/exkgrx1d0yoaIFHaF5d7/sso/saml', // SSO URL of the IdP
        ),
        'x509cert' => '-----BEGIN CERTIFICATE-----
        MIIDqDCCApCgAwIBAgIGAY8upyA8MA0GCSqGSIb3DQEBCwUAMIGUMQswCQYDVQQGEwJVUzETMBEG
        A1UECAwKQ2FsaWZvcm5pYTEWMBQGA1UEBwwNU2FuIEZyYW5jaXNjbzENMAsGA1UECgwET2t0YTEU
        MBIGA1UECwwLU1NPUHJvdmlkZXIxFTATBgNVBAMMDGRldi02MDcwMDkzNjEcMBoGCSqGSIb3DQEJ
        ARYNaW5mb0Bva3RhLmNvbTAeFw0yNDA0MzAxMDU2MzVaFw0zNDA0MzAxMDU3MzVaMIGUMQswCQYD
        VQQGEwJVUzETMBEGA1UECAwKQ2FsaWZvcm5pYTEWMBQGA1UEBwwNU2FuIEZyYW5jaXNjbzENMAsG
        A1UECgwET2t0YTEUMBIGA1UECwwLU1NPUHJvdmlkZXIxFTATBgNVBAMMDGRldi02MDcwMDkzNjEc
        MBoGCSqGSIb3DQEJARYNaW5mb0Bva3RhLmNvbTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
        ggEBAJk/m8LiA+fpPRUAp+jv/HEflNq/1XkgoxbLcqtrL+J5mUC377Ax5JJO9s5CAHo/szs3cHyK
        y1CU6+jNHUSytTqT+QKcLVxGGHHAW0xDKbpK+bz9iQojrznoCQsVZPKBmexWrBCWN3l6eJNrGcpM
        iFdmzjMCzbkW6S3bXMf+oN1OcUv5CstQo33f8ih6bEdCqujTDDhu4f3yJljG2HrELiIa3V53Tqqs
        muIpJdtCidLimEb2Hmyyr5nOHw5CaNAwzEtPZjFp/fo5sd35hTMYhb6cXKdAnKwBrZNZAZ3eSQb1
        kvesilyp24T3jnqm4dbgcX/057LpJbZdEpdDPZmooikCAwEAAaMhMB8wHQYDVR0OBBYEFH/TZafC
        3ey78DAJ80M5+gM2X+P0MB0GA1UdDgQWBBQVj4DRFtk7u3mzAwhpTcr2aCuUaDANBgkqhkiG9w0B
        AQ0FAAOCAQEAUB9Byiw0H90cb5jFwn/rKszhfHs+yx3KKfZ43ancx0uglvl5kQCwrc+Qvo0NxBRE
        lWupahC24meOkapIyLLhtsTjnDa6S3SJpRBrrZ5sNkjNncgtazglCeUr7ff6sLG8Iy9XjeB/iu1V
        5JwtOn44Hh1a267NwNDjK0VFTAY0hbTWrE4iFaSXnnhc6dCMUeUtbca5jJZi2q0UTabXBnXZ8EKa
        Z22NiSVcmcUciAMJmyOUtBeEJAG2a6/noMd/NrkmUvejfhkC8u4GEaJU33g8GiZ68rfbFlvPosS2
        +kNymm2tM7Ywrg5U6CbJiYXyu1v2WcSaus0vPLd59/vtfsEFig==
        -----END CERTIFICATE-----', // x509 certificate of the IdP
        // Other IdP settings as needed
    ),
    // Other settings as needed
);

use OneLogin\Saml2\Auth;

$auth = new Auth($settings);

// Initiate the SAML authentication process
$auth->login();

// Get the SAML request
$samlRequest = $auth->getLastRequestXML();

// Display the SAML request
echo "SAML Request: <pre>" . htmlentities($samlRequest) . "</pre>";
?>
