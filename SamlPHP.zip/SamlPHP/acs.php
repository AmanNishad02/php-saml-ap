<?php
require_once 'settings.php';
require_once 'vendor/autoload.php';

use OneLogin\Saml2\Auth;

$auth = new Auth($settings);

if (isset($_REQUEST['SAMLResponse'])) {
    $auth->processResponse();

    $errors = $auth->getErrors();

    if (!empty($errors)) {
        echo "<p>Error: ", implode(', ', $errors), "</p>";
    } else {
        $attributes = $auth->getAttributes();
        // Access the authenticated user's attributes
        // e.g., $username = $attributes['username'][0];
        // ...

        // Start user session here
        session_start();
        $_SESSION['logged_in'] = true;
        // ...

        // Redirect to the protected area
        header('Location: https://your-domain.com/protected_area.php');
        exit();
    }
} else {
    echo "<p>Invalid SAML Response</p>";
}