<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .container {
            max-width: 400px;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }
        p {
            text-align: center;
            margin-bottom: 20px;
            color: #666;
        }
        .login-btn {
            display: block;
            width: 100%;
            padding: 12px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-align: center;
            font-size: 16px;
            transition: background-color 0.3s;
        }
        .login-btn:hover {
            background-color: #0056b3;
        }
        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            margin-bottom: 10px;
            box-sizing: border-box;
            font-size: 16px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 6px;
            color: #333;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Login Page</h1>
        <div class="form-group">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>
        </div>
        <div class="form-group">
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
        </div>
        <button class="login-btn" onclick="window.location.href='?login=true'">Login with Okta</button>
    </div>
    
    <?php
    require_once('vendor/autoload.php');

    $settings = array(
        'sp' => array(
            'entityId' => 'http://www.okta.com/exkgrx1d0yoaIFHaF5d7',
            'assertionConsumerService' => array(
                'url' => 'http://localhost/SamlPHP/protected_area.php',
            ),
        ),
        'idp' => array(
            'entityId' => 'http://www.okta.com/exkgrx1d0yoaIFHaF5d7',
            'singleSignOnService' => array(
                'url' => 'https://dev-60700936.okta.com/app/dev-60700936_samplephpapp_1/exkgrx1d0yoaIFHaF5d7/sso/saml',
            ),
            'x509cert' => '-----BEGIN CERTIFICATE-----
            MIIDqDCCApCgAwIBAgIGAY8upyA8MA0GCSqGSIb3DQEBCwUAMIGUMQswCQYDVQQGEwJVUzETMBEG A1UECAwKQ2FsaWZvcm5pYTEWMBQGA1UEBwwNU2FuIEZyYW5jaXNjbzENMAsGA1UECgwET2t0YTEU MBIGA1UECwwLU1NPUHJvdmlkZXIxFTATBgNVBAMMDGRldi02MDcwMDkzNjEcMBoGCSqGSIb3DQEJ ARYNaW5mb0Bva3RhLmNvbTAeFw0yNDA0MzAxMDU2MzVaFw0zNDA0MzAxMDU3MzVaMIGUMQswCQYD VQQGEwJVUzETMBEGA1UECAwKQ2FsaWZvcm5pYTEWMBQGA1UEBwwNU2FuIEZyYW5jaXNjbzENMAsG A1UECgwET2t0YTEUMBIGA1UECwwLU1NPUHJvdmlkZXIxFTATBgNVBAMMDGRldi02MDcwMDkzNjEc MBoGCSqGSIb3DQEJARYNaW5mb0Bva3RhLmNvbTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC ggEBAJk/m8LiA+fpPRUAp+jv/HEflNq/1XkgoxbLcqtrL+J5mUC377Ax5JJO9s5CAHo/szs3cHyK y1CU6+jNHUSytTqT+QKcLVxGGHHAW0xDKbpK+bz9iQojrznoCQsVZPKBmexWrBCWN3l6eJNrGcpM iFdmzjMCzbkW6S3bXMf+oN1OcUv5CstQo33f8ih6bEdCqujTDDhu4f3yJljG2HrELiIa3V53Tqqs muIpJdtCidLimEb2Hmyyr5nOHw5CaNAwzEtPZjFp/fo5sd35hTMYhb6cXKdAnKwBrZNZAZ3eSQb1 kvesilyp24T3jnqm4dbgcX/057LpJbZdEpdDPZmooikCAwEAAaMhMB8wHQYDVR0OBBYEFH/TZafC 3ey78DAJ80M5+gM2X+P0MB0GA1UdDgQWBBQVj4DRFtk7u3mzAwhpTcr2aCuUaDANBgkqhkiG9w0B AQ0FAAOCAQEAUB9Byiw0H90cb5jFwn/rKszhfHs+yx3KKfZ43ancx0uglvl5kQCwrc+Qvo0NxBRE lWupahC24meOkapIyLLhtsTjnDa6S3SJpRBrrZ5sNkjNncgtazglCeUr7ff6sLG8Iy9XjeB/iu1V 5JwtOn44Hh1a267NwNDjK0VFTAY0hbTWrE4iFaSXnnhc6dCMUeUtbca5jJZi2q0UTabXBnXZ8EKa Z22NiSVcmcUciAMJmyOUtBeEJAG2a6/noMd/NrkmUvejfhkC8u4GEaJU33g8GiZ68rfbFlvPosS2 +kNymm2tM7Ywrg5U6CbJiYXyu1v2WcSaus0vPLd59/vtfsEFig==
            -----END CERTIFICATE-----',
        ),
    );

    use OneLogin\Saml2\Auth;

    $auth = new Auth($settings);

    // Check if the user clicked the "Login with Okta" link
    if (isset($_GET['login']) && $_GET['login'] === 'true') {
        // Initiate the SAML authentication process
        $auth->login();

        // Get the SAML request
        $samlRequest = $auth->getLastRequestXML();

        // Display the SAML request
        echo "SAML Request: <pre>" . htmlentities($samlRequest) . "</pre>";
    }
    ?>
</body>
</html>
